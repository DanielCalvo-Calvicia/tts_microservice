from dataclasses import dataclass
from typing import Literal
from dataclasses import field

from contracts.stream.common.base import BaseEvent, EventType
    
@dataclass(frozen=True, slots=True)
class HeartbeatEvent(BaseEvent[None]):
    type: Literal[EventType.HEARTBEAT] = field(
        default=EventType.HEARTBEAT,
        init=False,
    )