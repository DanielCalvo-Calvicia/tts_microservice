from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from contracts.api.common.stream import StreamDirection


@dataclass(slots=True, frozen=True)
class STTSetStreamRequest:
    session_id: str
    direction: StreamDirection = "inbound"
    chunk_bytes: int = 1024
    content_type: Optional[str] = "audio/L16"


@dataclass(slots=True, frozen=True)
class STTSetStreamResponse:
    session_id: str
    accepted: bool
    message: str
