"""TTS contracts."""
