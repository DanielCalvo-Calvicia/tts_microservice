"""Operational health contracts."""
