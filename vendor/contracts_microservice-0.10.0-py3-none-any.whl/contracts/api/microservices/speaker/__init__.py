"""Speaker contracts."""
